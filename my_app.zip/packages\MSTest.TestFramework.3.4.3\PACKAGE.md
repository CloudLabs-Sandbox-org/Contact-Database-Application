# MSTest.TestFramework

MSTest is Microsoft supported Test Framework.

This package includes the libraries for writing tests with MSTest. To ensure discovery and execution of your tests, install the MSTest.TestAdapter package.

Supported platforms:

- .NET 4.6.2+
- .NET Core 3.1+
- .NET 6.0+
- .NET 6.0 Windows.18362+
- UWP 10.0.16299
